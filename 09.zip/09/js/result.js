/**
  * @Description:
  * @author: Icon
  * @date: 2021/12/7
  * @time: 10:13
*/

function createResult() {
  if (hero.isOver) {
    clearInterval(timer);
    alert('game over');
  }
}
